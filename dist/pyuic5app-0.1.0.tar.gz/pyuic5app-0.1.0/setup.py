# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyuic5app']

package_data = \
{'': ['*']}

install_requires = \
['pyqt5>=5.15.7,<6.0.0', 'typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['pyuic5app = pyuic5app.main1:app']}

setup_kwargs = {
    'name': 'pyuic5app',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'asewvtft545456',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
